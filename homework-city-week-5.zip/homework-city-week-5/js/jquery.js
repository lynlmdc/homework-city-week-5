//enter city name in input field
//listen for .click event
//set up a .click change function
//use addClass method to call up images

$(document).ready(function(){

	$("#submit-btn").click(change);

	function change(){
		event.preventDefault();
		var city = $("#city-type").val();
		if(city == "NYC" || city == "New York City" || city == "Old York"){
			$("body").addClass("nyc");
		}
		if(city == "San Francisco" || city == "SF" || city == "Bay Area"){
			$("body").addClass("sf");
		}
		if(city == "Los Angeles" || city == "LA" || city == "LAX"){
			$("body").addClass("la");
		}
		if(city == "Austin" || city == "ATX"){
			$("body").addClass("austin");
		}
		if(city == "Sydney" || city == "SYD"){
			$("body").addClass("sydney");
		}
		$("#city-type").val("");
	}


});


